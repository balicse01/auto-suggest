﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace AutosuggestApp
{
    class Program
    {
        static string host = "https://api.cognitive.microsoft.com";
        static string path = "/bing/v7.0/Suggestions";
        static string market = "en-US";
        static string key = "87e8d78de450453587f170f373720223";
        public static string query;
   //public string query = "";
         
        async static void Autosuggest()
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", key);

            string uri = host + path + "?mkt=" + market + "&query=" + System.Net.WebUtility.UrlEncode(query);
           // Console.WriteLine(uri);
            HttpResponseMessage response = await client.GetAsync(uri);


            string contentString = await response.Content.ReadAsStringAsync();
            dynamic parsedJson = JsonConvert.DeserializeObject(contentString);

            //Console.WriteLine(parsedJson);
            Console.WriteLine("=====List of suggested queries are=======");
            int i = 1;
            foreach (var result in parsedJson.suggestionGroups[0]["searchSuggestions"])
            {
               // Console.WriteLine("=====List of suggested queries are=======");
                Console.WriteLine(i +" "+result["displayText"]);
                i++;
            }



        }

        static void Main(string[] args)
        {

            

            string flag = "y";
            string flag1 = "Y";
            while (flag == "y" || flag1 == "Y")
            {
                Console.Write("Enter a partial query to search : ");
                query = Console.ReadLine();
                Autosuggest();
                Console.ReadLine();
                //Console.Write("Do you want to continue the auto-suggest search - y/n: ");
            }

        }
    }
    public class MyItem
    {
        public string _type;
        public string queryContext;
        public string suggestionGroups;
        
    }
}
